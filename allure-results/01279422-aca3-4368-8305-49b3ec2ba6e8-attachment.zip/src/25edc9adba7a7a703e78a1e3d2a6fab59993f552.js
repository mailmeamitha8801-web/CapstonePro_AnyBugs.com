class FunctionalBugRepro{
  constructor(page){

    this.page=page;

    this.navigateButton=page.getByRole('link',{'name' : 'Apply now'});

    this.reportProduct
    
  }

  async applyNow()
  {

    await this.navigateButton.click();
  }

};
module.exports = { FunctionalBugRepro };