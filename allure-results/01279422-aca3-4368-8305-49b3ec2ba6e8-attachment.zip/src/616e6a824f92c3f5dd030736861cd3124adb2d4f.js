const { test, expect } = require("../fixtures/bug.fixture");

const { FunctionalBugRepro} = require("../pages/bugs/FunctionalBugRepro");


test('Functional Bug- Broken Links', async({bugApp})=>{

 const functionalbug= new FunctionalBugRepro(bugApp.page); 
 
 await bugApp.page.goto('/opportunities-we-provide/');

await functionalbug.applyNow();

await expect (bugApp.page).toHaveURL('/opportunities-we-provide/#');

console.log("Apply Now Button is broken....!!!")

});

//test('Functional Bug- Search option not showing the actual result');


