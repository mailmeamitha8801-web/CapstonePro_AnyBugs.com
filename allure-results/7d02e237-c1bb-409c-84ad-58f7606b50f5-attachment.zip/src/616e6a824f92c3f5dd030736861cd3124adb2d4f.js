const { test, expect } = require("../fixtures/bug.fixture");
const { FunctionalBugRepro} = require("../pages/bugs/FunctionalBugRepro");


test('Functional Bug- Broken Links', async({bugApp})=>{

 const functionalbug= new FunctionalBugRepro(bugApp.page); 
 
 await bugApp.page.goto('/opportunities-we-provide/');

await functionalbug.applyNow();

await expect (bugApp.page).toHaveURL('/opportunities-we-provide/#');

console.log("Apply Now Button is broken....!!!")

});

test('Functional Bug- Contact US Form not working properly', async({bugApp})=>{

    const contactuser = require('../testData/contactUser.json');
    
    const functionalbug= new FunctionalBugRepro(bugApp.page); 

    await bugApp.page.goto('/contact-us-form/');

    await functionalbug.sendEnquiry();
    
    await expect(this.errorMessage).toHaveText('Oops! Something went wrong.');

    console.log("Contact Form submission failed...!!")

});


