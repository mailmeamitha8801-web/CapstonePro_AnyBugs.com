/*class FunctionalBugRepro{
  constructor(page, contactuser){

    this.page=page;
    this.contactuser=contactuser;
    //locator for the test Apply Link button in the Article page
    this.navigateButton=page.getByRole('link',{'name' : 'Apply now'});

    // locators for the Contact US page bug
    this.customerFirstName=page.getByPlaceholder('First Name');
    this.customerLastName=page.getByPlaceholder('Last Name');
    this.customerEmail=page.getByPlaceholder('Email');
    this.customerSubject=page.getByPlaceholder('Subject');
    this.customerMessage=page.getByPlaceholder('Message');
    this.sendMessage=page.getByRole('button',{'name': 'Send'});
    this.errorMessage = this.page.locator('#wpforms-confirmation-1122 p');

   //locators for the Search Funtion bug
    this.bugPage= this.page.locator('a.example-tile-div').filter({hasText:'Search button leads to an error'});
    this.bugItem=this.page.locator('#popmake-4434');
    this.searchProduct=this.page.locator('.example-5-search-bug');
    //this.getProductTitle=this.page.locator('h1.ec_details_title').textContent();
    //this.searchBoxInput=this.page.locator('.ec_search_input');
    //this.enableSearch=this.page.getByRole('button',{'name': 'Search'});
    this.getProductTitle = this.page.locator('h1.ec_details_title');
    this.searchKeyword=this.getProductTitle.trim().split(' ')[0];
    this.searchBoxInput = this.page.locator('.ec_search_input');
    this.enableSearch = this.page.getByRole('button', { name: 'Search' });
    this.searchResultPage=this.page.getByContent('			Oops! That page can’t be found.		');
  }

  //Member Function for ApplyLink Bug
  async applyNow()
  {
    await this.navigateButton.click();
  }

 //Member function for Contact Us Bug
  async sendEnquiry(contactuser)
  {
    await this.customerFirstName.fill(contactuser.contactFormFName);
    await this.customerLastName.fill(contactuser.contactFormLName);
    await this.customerEmail.fill(contactuser.contactEmail);
    await this.customerSubject.fill(contactuser.ContactFormSubject);
    await this.customerMessage.fill(contactuser.contactFormMessage);
    await this.sendMessage.click();
    
  }

 //Member function for Search Bug Actions

async searchKeyWordFrame()
   {
       this.bugPage.click();
       this.bugItem.click();
   }

   async bugSearchKeyword() {

    const productTitle = await this.getProductTitle.textContent();
    this.searchKeyword = productTitle.trim().split(' ')[0];
    await this.searchBoxInput.fill(this.searchKeyword);
    await this.enableSearch.click();
}
  

};
module.exports = { FunctionalBugRepro };*/


class FunctionalBugRepro {
    constructor(page, contactuser) {

        this.page = page;
        this.contactuser = contactuser;

        // Locators for Apply Link bug
        this.navigateButton = page.getByRole('link', { name: 'Apply now' });

        // Locators for Contact Us bug
        this.customerFirstName = page.getByPlaceholder('First Name');
        this.customerLastName = page.getByPlaceholder('Last Name');
        this.customerEmail = page.getByPlaceholder('Email');
        this.customerSubject = page.getByPlaceholder('Subject');
        this.customerMessage = page.getByPlaceholder('Message');
        this.sendMessage = page.getByRole('button', { name: 'Send' });
        this.errorMessage = page.locator('#wpforms-confirmation-1122 p');

        // Locators for Search Functionality bug
        this.bugPage = page.locator('a.example-tile-div')
            .filter({ hasText: 'Search button leads to an error' });

        this.bugItem = page.locator('#popmake-4434');
        this.searchProduct = page.locator('.example-5-search-bug');

        this.getProductTitle = page.locator('h1.ec_details_title');
        this.searchBoxInput = page.locator('.ec_search_input');
        this.enableSearch = page.getByRole('button', { name: 'Search' });

        this.searchResultPage = page.getByText(
            'Oops! That page can’t be found.',
            { exact: true }
        );
    }

    // Member function for Apply Link bug
    async applyNow() {
        await this.navigateButton.click();
    }

    // Member function for Contact Us bug
    async sendEnquiry(contactuser) {
        await this.customerFirstName.fill(contactuser.contactFormFName);
        await this.customerLastName.fill(contactuser.contactFormLName);
        await this.customerEmail.fill(contactuser.contactEmail);
        await this.customerSubject.fill(contactuser.ContactFormSubject);
        await this.customerMessage.fill(contactuser.contactFormMessage);
        await this.sendMessage.click();
    }

    // Member functions for Search bug actions
    /*async searchKeyWordFrame() {
        await this.bugPage.click();
        await this.bugItem.click();
    }*/

    async bugSearchKeyword() {
        const productTitle = await this.getProductTitle.textContent();

        this.searchKeyword = productTitle.trim().split(' ')[0];

        await this.searchBoxInput.fill(this.searchKeyword);
        await this.enableSearch.click();
    }

async searchKeyWordFrame() {
    await this.bugPage.click({ force: true });
}

};

module.exports = { FunctionalBugRepro };
