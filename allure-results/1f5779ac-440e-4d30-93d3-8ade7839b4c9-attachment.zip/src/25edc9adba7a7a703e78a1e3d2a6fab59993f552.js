class FunctionalBugRepro{
  constructor(page){

    this.page=page;

    this.navigateButton=page.getByRole('button',{'name' : 'Apply now'});
    
  }

  async applyNow()
  {

    await this.navigateButton.click();
  }


}
module.exports = { FunctionalBugRepro };