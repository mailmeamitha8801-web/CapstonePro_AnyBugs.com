
class ContentBugRepro {
    constructor(page) {
        this.page = page;

        this.bugProduct = page
            .locator('#ec_store_product_list .ec_product_li').first();

        this.productCartButton = this.bugProduct.locator('button, a').filter({ hasText: /add to cart/i });
    }

    async instantAddToCart() {
        await this.productCartButton.click();
    }
}

module.exports = { ContentBugRepro };
