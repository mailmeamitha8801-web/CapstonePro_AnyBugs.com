const { test, expect } = require('../fixtures/bug.fixture');
const { VisualBugPage } = require("../pages/bugs/VisualBugPage");


test('Visual Bug-Broken Image Implanted Bug', async({bugApp})=>{

    const visualbugpage = new VisualBugPage(bugApp.page);

        await bugApp.page.goto('https://academybugs.com/articles/');

        await expect(visualbugpage.postImage).toBeAttached();

        const imageLoaded = await visualBugPage.postImage.evaluate(
            img => img.complete && img.naturalWidth > 0
        );

        expect(imageLoaded).toBe(false);

});