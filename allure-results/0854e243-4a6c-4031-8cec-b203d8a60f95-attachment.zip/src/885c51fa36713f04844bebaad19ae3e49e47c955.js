const { test } = require("../fixtures/bug.fixture");
const { VisualBugRepro, ContentBugRepro } = require("../pages/bugs/ContentBugRepro");

test('Content Bugs- Empty Cart Button Text Alignement', async({bugApp})=>{

    const contentbug= new ContentBugRepro(bugApp.page);
    await bugApp.page.goto('https://academybugs.com/find-bugs');
    await expect (bugApp.bugProduct).first().toBeVisible();
    await contentbug.instantAddToCart();
    //await expect (contentbug.productCheckOutButton).toBeVisible();
    await expect(bugApp.page.getByRole('button', { name: /checkout now/i })).toBeVisible();
    await bugApp.productCheckOutButton.click();
    await expect (bugApp.page).toHaveURL('/my-cart/');
    await contentbug.emptyCart();
    await expect (bugApp.emptyCartButton).toBeVisible();
    await expect (bugApp.emptyCartButton).toHaveText('RETURN TO STOR      E');
    
});