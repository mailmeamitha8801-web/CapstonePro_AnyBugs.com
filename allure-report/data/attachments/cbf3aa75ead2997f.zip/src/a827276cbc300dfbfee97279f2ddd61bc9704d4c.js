
class ContentBugRepro {
    constructor(page) {
        this.page = page;

        this.bugProduct = page.locator('#ec_store_product_list .ec_product_li').first();

        this.productCartButton = this.bugProduct.getByRole('link', { name: 'ADD TO CART' }).first();
    }

    async instantAddToCart() {
        await this.productCartButton.click();
    }
}

module.exports = { ContentBugRepro };
