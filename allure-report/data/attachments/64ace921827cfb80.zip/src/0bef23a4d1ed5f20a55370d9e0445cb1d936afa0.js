
const { test, expect } = require('../fixtures/bug.fixture');
const { CrashBugRepro } = require('../pages/bugs/CrashBugRepro');

test('Crash Bug - PDP becomes unresponsive after currency change', async ({ bugApp }) => {
  const crashbug = new CrashBugRepro(bugApp.page);

  // Navigate to the product listing page using baseURL
  await bugApp.page.goto('/store/');

  // Navigate to the first product detail page
  await crashbug.openFirstProductDetailPage();

  // Verify that the product detail page has loaded
  await expect(bugApp.page.locator('body')).toBeVisible();

  // Measure the time taken for the currency change and subsequent browser action
  const startTime = Date.now();

  await crashbug.changeCurrency('EUR');

  await bugApp.page.locator('body').evaluate(element => element.innerText);

  const timeTaken = Date.now() - startTime;

  console.log(`Time taken after currency change: ${timeTaken} ms`);

  // Bug reproduction: expect a delay of at least 4 seconds
  expect(timeTaken).toBeGreaterThanOrEqual(4000);
});
