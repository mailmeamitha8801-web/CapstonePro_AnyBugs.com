
const { test, expect } = require('../fixtures/bug.fixture');
const { CrashBugRepro } = require('../pages/bugs/CrashBugRepro');

test('Crash Bug - PDP unresponsive after currency change', async ({ bugApp }) => {
  const crashbug = new CrashBugRepro(bugApp.page);

  await bugApp.page.goto('/store/');

  await crashbug.openFirstProductDetailPage();

  // Schedule a timer before changing currency
  await bugApp.page.evaluate(() => {
    window.timerStart = Date.now();
    window.timerDelay = null;

    setTimeout(() => {
      window.timerDelay = Date.now() - window.timerStart;
    }, 100);
  });

  await crashbug.changeCurrency('EUR');

  // Allow the timer callback to execute
  await bugApp.page.waitForTimeout(6000);

  const timerDelay = await bugApp.page.evaluate(() => window.timerDelay);

  console.log(`JavaScript timer delay: ${timerDelay} ms`);

  expect(timerDelay).toBeGreaterThanOrEqual(4000);
});
