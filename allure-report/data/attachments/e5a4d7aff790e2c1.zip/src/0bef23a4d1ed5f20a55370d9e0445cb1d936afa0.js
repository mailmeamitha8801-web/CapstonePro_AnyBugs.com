
const { test, expect } = require('../fixtures/bug.fixture');
const { CrashBugRepro } = require('../pages/bugs/CrashBugRepro');

test('Crash Bug - PDP unresponsive after currency change', async ({ bugApp }) => {
  const crashbug = new CrashBugRepro(bugApp.page);

  await bugApp.page.goto('/store/');
  await crashbug.openFirstProductDetailPage();

  // Schedule a timer immediately before changing currency
  await bugApp.page.evaluate(() => {
    window.timerStart = Date.now();
    window.timerDelay = new Promise(resolve => {
      setTimeout(() => resolve(Date.now() - window.timerStart), 100);
    });
  });

  await crashbug.changeCurrency('EUR');

  // Read the actual timer delay
  const timerDelay = await bugApp.page.evaluate(() => window.timerDelay);

  console.log(`JavaScript timer delay: ${timerDelay} ms`);

  // Expect a delay of at least 4 seconds to reproduce the bug
  expect(timerDelay).toBeGreaterThanOrEqual(4000);
});
