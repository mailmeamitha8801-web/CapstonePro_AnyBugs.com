const { test, expect } = require('../fixtures/bug.fixture');
const { CrashBugRepro } = require('../pages/bugs/CrashBugRepro');

test('Crash Bug - PDP unresponsive after currency change', async ({ bugApp }) => {
  const crashbug = new CrashBugRepro(bugApp.page);

  // Open the product listing page using baseURL
  await bugApp.page.goto('/store/');

  // Navigate to the first product detail page
  await crashbug.openFirstProductDetailPage();

  // Continue with your currency-change scenario
});