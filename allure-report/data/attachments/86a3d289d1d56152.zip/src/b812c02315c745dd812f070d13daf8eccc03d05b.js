class CrashBugRepro {
  constructor(page) {
    this.page = page;

    this.firstProduct = page.locator('.ec_product_li a').first();

    // Replace with the actual currency dropdown locator
     this.currencyDropdown = page.locator('#ec_currency_conversion');
  }

  async openFirstProductDetailPage() {
    await this.firstProduct.click();
  }

  async changeCurrency(currencyValue) {
    await this.currencyDropdown.selectOption(currencyValue);
  }
}

module.exports = { CrashBugRepro };