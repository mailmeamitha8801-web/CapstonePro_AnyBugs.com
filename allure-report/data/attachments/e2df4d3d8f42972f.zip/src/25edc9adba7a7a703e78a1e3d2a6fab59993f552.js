class FunctionalBugRepro{
  constructor(page, contactuser){

    this.page=page;
    this.contactuser=contactuser;

    this.navigateButton=page.getByRole('link',{'name' : 'Apply now'});

    this.customerFirstName=page.getByPlaceholder('First Name');
    this.customerLastName=page.getByPlaceholder('Last Name');
    this.customerEmail=page.getByPlaceholder('Email');
    this.customerSubject=page.getByPlaceholder('Subject');
    this.customerMessage=page.getByPlaceholder('Message');
    this.sendMessage=page.getByRole('button',{'name': 'Send'});
    this.errorMessage = this.page.locator('#wpforms-confirmation-1122 p');
    
  }

  async applyNow()
  {
    await this.navigateButton.click();
  }

  async sendEnquiry(contactuser)
  {
    await this.customerFirstName.fill(contactuser.contactFormFName);
    await this.customerLastName.fill(contactuser.contactFormLName);
    await this.customerEmail.fill(contactuser.contactEmail);
    await this.customerSubject.fill(contactuser.ContactFormSubject);
    await this.customerMessage.fill(contactuser.contactFormMessage);
    await this.sendMessage.click();
    
  }

};
module.exports = { FunctionalBugRepro };