class ContentBugRepro{

     constructor(page){
        this.page=page;
        this.productCartButton=page.getByRole('button',{'name': '/add to cart/i'});
        this.productCheckOutButton=page.getByRole('button',{'name': 'CHECKOUT NOW'});
        this.productDeleteButton=page.locator('.ec_cartitem_delete');
        this.emptyCartButton=page.locator('ec_cart_empty_button academy-bug');

     }

     async instantAddToCart()        
        {
           await this.productCartButton.first().click();
           
        }

     async instantCheckOut()
     {
        await this.productDeleteButton.click();
     }
    
    async emptyCart()
    {
      await this.productDeleteButton.click();

    }
   

};

module.exports={ContentBugRepro};